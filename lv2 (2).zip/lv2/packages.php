<?php
//get data from form  

$name ="Name = ". $_POST['name'].".\r\n";
$number ="Mobile Number =". $_POST['number'].".\r\n";
$pickup="Pickup Location =". $_POST['pickup'].".\r\n";
$date="Date =". $_POST['date'].".\r\n";
$time="Time =". $_POST['time'].".\r\n";
$email="Email =". $_POST['email'].".\r\n";
$suggestion="Message =". $_POST['suggestion'].".\r\n";
$days="No Of Days =". $_POST['days'].".\r\n";
$type= $_POST['type'];





$to ="info@lvlogistic.in";
$subject = "Cab Packages Enquiry from $type";
$txt = $name.$number.$email.$pickup.$date.$time.$days.$suggestion;
$headers = "From:lvlogistics.blr@gmail.com" . "\r\n" .
"CC:lvlogistics.blr@gmail.com";
mail($to,$subject,$txt,$headers);
header("Location:thankyou.html");
?>
