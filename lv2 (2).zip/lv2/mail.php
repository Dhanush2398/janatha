<?php
//get data from form  

$name ="Name = ". $_POST['name'].".\r\n";
$number ="Mobile Number =". $_POST['number'].".\r\n";
$pickup="Pickup Location =". $_POST['pickup'].".\r\n";
$date="Date =". $_POST['date'].".\r\n";
$time="Time =". $_POST['time'].".\r\n";
$email="Email =". $_POST['email'].".\r\n";
$suggestion="Suggestion =". $_POST['suggestion'].".\r\n";
$vehicle="Vehicle Type =". $_POST['vehicle'].".\r\n";





$to ="info@lvlogistic.in";
$subject = "Destinations Enquiry";
$txt = $name.$number.$email.$vehicle.$pickup.$date.$time.$suggestion;
$headers = "From:lvlogistics.blr@gmail.com" . "\r\n" .
"CC:lvlogistics.blr@gmail.com";
mail($to,$subject,$txt,$headers);
header("Location:thankyou.html");
?>
