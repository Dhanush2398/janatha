<?php
//get data from form  

$name ="Name = ". $_POST['name'].".\r\n";
$dutytype ="Duty Type = ". $_POST['dutytype'].".\r\n";
$number ="Mobile Number =". $_POST['number'].".\r\n";
$pickup="Pickup Location =". $_POST['pickup'].".\r\n";
$date="Date =". $_POST['date'].".\r\n";
$time="Time =". $_POST['time'].".\r\n";
$email="Email =". $_POST['email'].".\r\n";
$suggestion="Suggestion =". $_POST['suggestion'].".\r\n";
$vehicle="Vehicle Type =". $_POST['vehicle'].".\r\n";
$drop = $_POST['drop'];
 if (empty($drop)) {
        $dropl="";
    } else {
       $dropl="Drop Location =". $_POST['drop'].".\r\n";
    }




$to ="info@lvlogistic.in";
$subject = "Cab Booking";
$txt = $name.$number.$email.$vehicle.$pickup.$dropl.$dutytype.$date.$time.$suggestion;
$headers = "From:lvlogistics.blr@gmail.com" . "\r\n" .
"CC:lvlogistics.blr@gmail.com";
mail($to,$subject,$txt,$headers);

header("Location:thankyou.html");
?>
